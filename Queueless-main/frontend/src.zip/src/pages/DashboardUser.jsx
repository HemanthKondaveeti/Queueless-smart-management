import React, { useEffect, useState } from 'react';
import axios from '../utils/axios';
import { motion } from 'framer-motion';
import MainLayout from '../layouts/MainLayout';

const DashboardUser = () => {
  const [centers, setCenters] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [slots, setSlots] = useState([]);
  const [selectedCenter, setSelectedCenter] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [tokenInfo, setTokenInfo] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchCenters = async () => {
      try {
        const res = await axios.get('/centers');
        setCenters(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchCenters();
  }, []);

  useEffect(() => {
    const fetchDepartments = async () => {
      if (!selectedCenter) return;
      try {
        const res = await axios.get(`/centers/${selectedCenter}/departments`);
        setDepartments(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchDepartments();
  }, [selectedCenter]);

  useEffect(() => {
    const fetchSlots = async () => {
      if (!selectedDept) return;
      try {
        const res = await axios.get(`/departments/${selectedDept}/slots`);
        setSlots(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchSlots();
  }, [selectedDept]);

  const handleBooking = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/tokens/book', {
        centerId: selectedCenter,
        departmentId: selectedDept,
        slotTime: selectedSlot,
      });
      setTokenInfo(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gray-800"
      >
        <h2 className="text-3xl font-extrabold mb-8">Book Your Token</h2>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <select
            value={selectedCenter}
            onChange={(e) => setSelectedCenter(e.target.value)}
            className="bg-white/70 backdrop-blur-md text-gray-800 p-3 rounded-xl w-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            <option value="">Select Service Center</option>
            {centers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            disabled={!selectedCenter}
            className="bg-white/70 backdrop-blur-md text-gray-800 p-3 rounded-xl w-full border border-gray-300 disabled:opacity-50"
          >
            <option value="">Select Department</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={selectedSlot}
            onChange={(e) => setSelectedSlot(e.target.value)}
            disabled={!selectedDept}
            className="bg-white/70 backdrop-blur-md text-gray-800 p-3 rounded-xl w-full border border-gray-300 disabled:opacity-50"
          >
            <option value="">Select Time Slot</option>
            {slots.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleBooking}
          disabled={!selectedCenter || !selectedDept || !selectedSlot || loading}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-lg font-semibold transition duration-200 disabled:opacity-50"
        >
          {loading ? 'Booking...' : 'Book Token'}
        </button>

        {tokenInfo && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mt-10 p-6 bg-white/70 backdrop-blur-md rounded-xl shadow-xl text-gray-800"
          >
            <h3 className="text-xl font-bold mb-3">🎟️ Your Token</h3>
            <p className="mb-1"><strong>Token Number:</strong> {tokenInfo.tokenNumber}</p>
            <p className="mb-3"><strong>Estimated Wait:</strong> {tokenInfo.estimatedWait} minutes</p>
            <div className="mt-4">
              <img
                src={`data:image/png;base64,${tokenInfo.qrCodeBase64}`}
                alt="QR Code"
                className="w-32 h-32"
              />
            </div>
          </motion.div>
        )}
      </motion.div>
    </MainLayout>
  );
};

export default DashboardUser;
