import React, { useState } from 'react';
import axios from '../utils/axios';
import { motion } from 'framer-motion';
import MainLayout from '../layouts/MainLayout';

const NotificationSender = () => {
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('');

  const sendNotification = async () => {
    try {
      await axios.post('/admin/notify', { message });
      setStatus('✅ Notification sent!');
      setMessage('');
    } catch (err) {
      setStatus('❌ Failed to send notification.');
    }
  };

  return (
    <MainLayout>
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-xl mx-auto text-gray-800"
      >
        <h2 className="text-2xl font-bold mb-4">Manual Notification Sender</h2>
        <textarea
          rows={4}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message here..."
          className="w-full max-w-lg px-4 py-3 bg-white border border-gray-300 rounded-lg"
        />
        <div className="mt-4">
          <button
            onClick={sendNotification}
            className="bg-indigo-600 hover:bg-indigo-700 px-6 py-2 rounded-lg text-white"
          >
            Send Notification
          </button>
          {status && <p className="mt-3 text-sm">{status}</p>}
        </div>
      </motion.div>
    </MainLayout>
  );
};

export default NotificationSender;
