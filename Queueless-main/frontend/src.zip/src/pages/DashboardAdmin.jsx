import React, { useEffect, useState } from 'react';
import axios from '../utils/axios';
import { motion } from 'framer-motion';
import MainLayout from '../layouts/MainLayout';

const DashboardAdmin = () => {
  const [queues, setQueues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [announcement, setAnnouncement] = useState('');

  useEffect(() => {
    const fetchQueues = async () => {
      try {
        const res = await axios.get('/admin/queues');
        setQueues(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchQueues();
  }, []);

  const markServed = async (tokenId) => {
    try {
      await axios.put(`/admin/queue/${tokenId}/served`);
      setQueues((prev) =>
        prev.map((q) => (q.id === tokenId ? { ...q, status: 'SERVED' } : q))
      );
    } catch (err) {
      console.error(err);
    }
  };

  const sendAnnouncement = async () => {
    if (!announcement.trim()) return;
    try {
      await axios.post('/admin/notify', { message: announcement });
      setAnnouncement('');
      alert('✅ Announcement sent!');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <MainLayout>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-gray-800"
      >
        <h2 className="text-4xl font-extrabold mb-10">Admin Dashboard</h2>

        {/* Announcement */}
        <div className="bg-white/60 backdrop-blur-lg p-6 rounded-2xl mb-10 shadow-xl border border-red-200">
          <h3 className="text-lg font-semibold mb-4 text-red-600">📢 Emergency Announcement</h3>
          <div className="flex flex-col sm:flex-row gap-4">
            <input
              value={announcement}
              onChange={(e) => setAnnouncement(e.target.value)}
              placeholder="Type message..."
              className="flex-1 px-4 py-2 rounded-lg bg-white text-gray-800 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-300"
            />
            <button
              onClick={sendAnnouncement}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-medium transition duration-200"
            >
              Send
            </button>
          </div>
        </div>

        {/* Live Queues */}
        <h3 className="text-xl font-semibold mb-4">🎯 Live Queues</h3>
        {loading ? (
          <p className="text-slate-500">Loading queues...</p>
        ) : queues.length === 0 ? (
          <p className="text-slate-400 italic">No active queues found.</p>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {queues.map((q) => (
              <motion.div
                key={q.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className={`p-5 rounded-xl shadow-lg bg-white/60 backdrop-blur-md border-l-4 ${
                  q.status === 'SERVED' ? 'border-green-500' : 'border-blue-500'
                }`}
              >
                <h4 className="text-xl font-bold mb-2">{q.tokenNumber}</h4>
                <p className="text-sm"><strong>Dept:</strong> {q.department}</p>
                <p className="text-sm"><strong>Time:</strong> {q.slotTime}</p>
                <p className="text-sm"><strong>Status:</strong> {q.status}</p>
                {q.status !== 'SERVED' && (
                  <button
                    onClick={() => markServed(q.id)}
                    className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm rounded-lg"
                  >
                    Mark as Served
                  </button>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </MainLayout>
  );
};

export default DashboardAdmin;
