import React, { useState } from 'react';
import axios from '../utils/axios';
import { motion } from 'framer-motion';
import MainLayout from '../layouts/MainLayout';

const ScanSimulator = () => {
  const [tokenInput, setTokenInput] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleScan = async () => {
    if (!tokenInput.trim()) return;
    setLoading(true);
    try {
      const res = await axios.post('/admin/scan', { token: tokenInput });
      setResult({ success: true, data: res.data });
    } catch (err) {
      setResult({
        success: false,
        message: err?.response?.data?.message || 'Scan failed.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-xl mx-auto p-8 bg-white/80 backdrop-blur rounded-xl shadow-xl text-gray-800"
      >
        <h2 className="text-2xl font-bold mb-4">QR Scan Simulator</h2>

        <input
          value={tokenInput}
          onChange={(e) => setTokenInput(e.target.value)}
          placeholder="Enter Token ID or Code"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4"
        />

        <button
          onClick={handleScan}
          disabled={loading}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-lg shadow disabled:opacity-50"
        >
          {loading ? 'Scanning...' : 'Simulate Scan'}
        </button>

        {result && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mt-6 p-4 rounded-lg text-white ${
              result.success ? 'bg-emerald-600' : 'bg-red-600'
            }`}
          >
            {result.success ? (
              <div>
                <p className="font-semibold">✅ Token Verified</p>
                <p className="text-sm mt-2">Token: {result.data.tokenNumber}</p>
                <p className="text-sm">Dept: {result.data.department}</p>
                <p className="text-sm">Slot: {result.data.slotTime}</p>
              </div>
            ) : (
              <p className="font-semibold">❌ {result.message}</p>
            )}
          </motion.div>
        )}
      </motion.div>
    </MainLayout>
  );
};

export default ScanSimulator;
