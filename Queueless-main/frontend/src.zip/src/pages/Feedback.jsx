import React, { useState } from 'react';
import axios from '../utils/axios';
import { motion } from 'framer-motion';

const Feedback = () => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!rating || !comment) return alert('Please rate and comment.');
    try {
      await axios.post('/feedback', { rating, comment });
      setSubmitted(true);
      setComment('');
      setRating(0);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-xl mx-auto mt-16 bg-white/60 backdrop-blur-xl p-8 rounded-2xl shadow-2xl"
    >
      <h2 className="text-3xl font-extrabold mb-6 text-center">We value your feedback 💬</h2>

      {submitted ? (
        <div className="text-center text-emerald-500 text-lg font-medium">
          ✅ Thank you for your feedback!
        </div>
      ) : (
        <>
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-700">Your Rating</label>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  onClick={() => setRating(star)}
                  className={`cursor-pointer text-3xl transition ${
                    star <= rating ? 'text-yellow-400' : 'text-slate-400'
                  }`}
                >
                  ★
                </span>
              ))}
            </div>
          </div>

          <textarea
            rows="4"
            placeholder="Write your comments here..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="w-full p-4 bg-white/30 text-gray-800 placeholder-gray-500 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 mb-6"
          />

          <div className="text-center">
            <button
              onClick={handleSubmit}
              className="bg-indigo-600 hover:bg-indigo-700 px-6 py-2 rounded-xl text-white font-semibold shadow transition duration-200"
            >
              Submit Feedback
            </button>
          </div>
        </>
      )}
    </motion.div>
  );
};

export default Feedback;
