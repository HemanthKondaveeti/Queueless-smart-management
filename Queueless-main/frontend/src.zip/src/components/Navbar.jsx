import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { isAuthenticated, getUserRole, logout } from '../utils/auth';

const Navbar = () => {
  const navigate = useNavigate();
  const isLoggedIn = isAuthenticated();
  const role = getUserRole();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="px-6 py-4 flex justify-between items-center border-b shadow-sm bg-white/30 backdrop-blur-md sticky top-0 z-50">
      {/* Logo */}
      <div className="flex items-center space-x-2">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-md">
          <span className="text-white text-lg font-bold">Q</span>
        </div>
        <span className="text-2xl font-extrabold text-gray-800 tracking-tight">Queueless</span>
      </div>

      {/* Navigation Links */}
      <nav className="space-x-6 text-sm font-medium text-gray-700">
        <Link to="/" className="hover:text-blue-600">Home</Link>

        {!isLoggedIn && (
          <>
            <Link to="/login" className="hover:text-blue-600">Login</Link>
            <Link to="/register" className="hover:text-blue-600">Register</Link>
          </>
        )}

        {isLoggedIn && role === 'USER' && (
          <>
            <Link to="/dashboard/user" className="hover:text-blue-600">Dashboard</Link>
            <Link to="/feedback" className="hover:text-blue-600">Feedback</Link>
            <button onClick={handleLogout} className="hover:text-red-600">Logout</button>
          </>
        )}

        {isLoggedIn && role === 'ADMIN' && (
          <>
            <Link to="/dashboard/admin" className="hover:text-blue-600">Dashboard</Link>
            <Link to="/notifications" className="hover:text-blue-600">Notifications</Link>
            <button onClick={handleLogout} className="hover:text-red-600">Logout</button>
          </>
        )}
      </nav>
    </header>
  );
};

export default Navbar;
