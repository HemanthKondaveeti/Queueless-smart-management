import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import DashboardUser from '../pages/DashboardUser';
import DashboardAdmin from '../pages/DashboardAdmin';
import Feedback from '../pages/Feedback';
import ScanSimulator from '../pages/ScanSimulator';
import NotificationSender from '../pages/NotificationSender';
import NotFound from '../pages/NotFound';

import ProtectedRoute from './ProtectedRoute';
import MainLayout from '../layouts/MainLayout';
import DashboardLayout from '../layouts/DashboardLayout';

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public routes inside MainLayout */}
        <Route element={<MainLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="*" element={<NotFound />} />
        </Route>

        {/* Protected routes inside DashboardLayout */}
        <Route
          element={
            <ProtectedRoute role="USER">
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard/user" element={<DashboardUser />} />
          <Route path="/feedback" element={<Feedback />} />
        </Route>

        <Route
          element={
            <ProtectedRoute role="ADMIN">
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard/admin" element={<DashboardAdmin />} />
          <Route path="/scan-simulator" element={<ScanSimulator />} />
          <Route path="/notifications" element={<NotificationSender />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
